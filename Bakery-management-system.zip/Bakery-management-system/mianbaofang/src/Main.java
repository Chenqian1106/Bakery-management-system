import controller.MainController;

public class Main {
    public static void main(String[] args) {
        MainController app = new MainController();
        app.start();
    }
}
