package service;

import utile.Data04Utile;
import java.io.FileWriter;
import java.sql.*;
import java.util.Map;

public class SalesService {

    /** 创建销售记录并扣减库存 */
    public void createSale(int empId, Map<Integer, Integer> productQtyMap, String paymentMethod, String remark) throws Exception {
        Connection c = Data04Utile.getConnection();
        try {
            c.setAutoCommit(false);
            double total = 0;
            for (Map.Entry<Integer, Integer> en : productQtyMap.entrySet()) {
                int pid = en.getKey();
                int qty = en.getValue();
                double price = getPrice(c, pid);
                total += price * qty;
                try (PreparedStatement psInv = c.prepareStatement("UPDATE inventory SET quantity = quantity - ?, update_time = NOW() WHERE product_id = ? AND quantity >= ?")) {
                    psInv.setInt(1, qty);
                    psInv.setInt(2, pid);
                    psInv.setInt(3, qty);
                    int updated = psInv.executeUpdate();
                    if (updated == 0) throw new SQLException("库存不足 productId=" + pid);
                }
            }

            String orderNo = generateOrderNo();
            int saleId;
            try (PreparedStatement psSale = c.prepareStatement("INSERT INTO sales(order_no, emp_id, total_amount, payment_method, remark) VALUES(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                psSale.setString(1, orderNo);
                psSale.setInt(2, empId);
                psSale.setDouble(3, total);
                psSale.setString(4, paymentMethod);
                psSale.setString(5, remark);
                psSale.executeUpdate();
                try (ResultSet rs = psSale.getGeneratedKeys()) {
                    rs.next();
                    saleId = rs.getInt(1);
                }
            }

            for (Map.Entry<Integer, Integer> en : productQtyMap.entrySet()) {
                int pid = en.getKey();
                int qty = en.getValue();
                double price = getPrice(c, pid);
                try (PreparedStatement psItem = c.prepareStatement("INSERT INTO sales_item(sale_id, product_id, qty, unit_price, line_total) VALUES(?,?,?,?,?)")) {
                    psItem.setInt(1, saleId);
                    psItem.setInt(2, pid);
                    psItem.setInt(3, qty);
                    psItem.setDouble(4, price);
                    psItem.setDouble(5, price * qty);
                    psItem.executeUpdate();
                }
            }
            c.commit();
        } catch (Exception ex) {
            c.rollback();
            throw ex;
        } finally {
            c.setAutoCommit(true);
            c.close();
        }
    }

    private double getPrice(Connection c, int productId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT price FROM product WHERE product_id = ?")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("price");
            }
        }
        throw new SQLException("商品价格读取失败");
    }

    private String generateOrderNo() {
        return "ORD" + System.currentTimeMillis();
    }

    /** 导出销售报表（txt） */
    public void exportReport(String filePath) throws Exception {
        String sql = "SELECT s.order_no, s.total_amount, s.payment_method, s.sale_time, e.emp_name FROM sales s JOIN employee e ON s.emp_id=e.emp_id ORDER BY s.sale_time DESC";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery();
             FileWriter fw = new FileWriter(filePath)) {
            fw.write("订单号\t金额\t支付方式\t销售时间\t操作员\n");
            while (rs.next()) {
                fw.write(String.format("%s\t%.2f\t%s\t%s\t%s\n",
                        rs.getString("order_no"),
                        rs.getDouble("total_amount"),
                        rs.getString("payment_method"),
                        rs.getString("sale_time"),
                        rs.getString("emp_name")));
            }
        }
    }
}
