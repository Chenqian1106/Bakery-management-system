package service;

import entity.EmpEntity;
import utile.Data04Utile;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpService {

    /** 登录验证 */
    public EmpEntity login(String account, String password) throws SQLException {
        String sql = "SELECT emp_id, emp_name, emp_role, emp_account, emp_password, hire_date FROM employee WHERE emp_account = ? AND emp_password = ?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, account);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    EmpEntity e = new EmpEntity();
                    e.setEmpId(rs.getInt("emp_id"));
                    e.setEmpName(rs.getString("emp_name"));
                    e.setEmpRole(rs.getString("emp_role"));
                    e.setEmpAccount(rs.getString("emp_account"));
                    e.setEmpPassword(rs.getString("emp_password"));
                    e.setHireDate(rs.getString("hire_date"));
                    return e;
                }
            }
        }
        return null;
    }

    /** 新增员工（仅店长可用） */
    public void addEmployee(String name, String role, String account, String password) throws SQLException {
        String sql = "INSERT INTO employee(emp_name, emp_role, emp_account, emp_password, hire_date) VALUES(?,?,?,?,NOW())";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, role);
            ps.setString(3, account);
            ps.setString(4, password);
            ps.executeUpdate();
        }
    }

    /** 修改员工信息 */
    public void updateEmployee(int id, String name, String role, String password) throws SQLException {
        String sql = "UPDATE employee SET emp_name=?, emp_role=?, emp_password=? WHERE emp_id=?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, role);
            ps.setString(3, password);
            ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    /** 删除员工（仅店长可用） */
    public void deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM employee WHERE emp_id=?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /** 查询所有员工 */
    public List<EmpEntity> listEmployees() throws SQLException {
        String sql = "SELECT emp_id, emp_name, emp_role, emp_account, hire_date FROM employee ORDER BY emp_id";
        List<EmpEntity> list = new ArrayList<>();
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                EmpEntity e = new EmpEntity();
                e.setEmpId(rs.getInt("emp_id"));
                e.setEmpName(rs.getString("emp_name"));
                e.setEmpRole(rs.getString("emp_role"));
                e.setEmpAccount(rs.getString("emp_account"));
                e.setHireDate(rs.getString("hire_date"));
                list.add(e);
            }
        }
        return list;
    }
}
