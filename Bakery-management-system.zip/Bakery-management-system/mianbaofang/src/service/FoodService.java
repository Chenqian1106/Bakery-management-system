package service;

import entity.FoodEntity;
import utile.Data04Utile;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FoodService {

    /** 查询在售面包 */
    public List<FoodEntity> listActiveFoods() throws Exception {
        String sql = "SELECT product_id, product_name, category, price, unit, description, status FROM product WHERE status='ACTIVE'";
        List<FoodEntity> list = new ArrayList<>();
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                FoodEntity f = new FoodEntity();
                f.setProductId(rs.getInt("product_id"));
                f.setProductName(rs.getString("product_name"));
                f.setCategory(rs.getString("category"));
                f.setPrice(rs.getDouble("price"));
                f.setUnit(rs.getString("unit"));
                f.setDescription(rs.getString("description"));
                f.setStatus(rs.getString("status"));
                list.add(f);
            }
        }
        return list;
    }

    /** 新增面包 */
    public void addFood(String name, String category, double price, String unit, String desc) throws Exception {
        String sql = "INSERT INTO product(product_name, category, price, unit, description, status) VALUES(?,?,?,?,?,'ACTIVE')";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, category);
            ps.setDouble(3, price);
            ps.setString(4, unit);
            ps.setString(5, desc);
            ps.executeUpdate();
        }
    }

    /** 修改面包信息 */
    public void updateFood(int id, String name, double price, String desc) throws Exception {
        String sql = "UPDATE product SET product_name=?, price=?, description=? WHERE product_id=?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setString(3, desc);
            ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    /** 下架面包 */
    public void deactivateFood(int id) throws Exception {
        String sql = "UPDATE product SET status='INACTIVE' WHERE product_id=?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public double getPriceById(int productId) throws Exception {
        String sql = "SELECT price FROM product WHERE product_id=?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("price");
            }
        }
        throw new RuntimeException("商品不存在");
    }

    public int getInventory(int productId) throws Exception {
        String sql = "SELECT quantity FROM inventory WHERE product_id = ?";
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("quantity");
            }
        }
        return 0;
    }
}
