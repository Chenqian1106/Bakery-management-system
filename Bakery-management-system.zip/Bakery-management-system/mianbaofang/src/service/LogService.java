package service;

import entity.LogEntity;
import utile.Data04Utile;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LogService {
    public List<LogEntity> queryLogs(String orderNo, Integer empId) throws Exception {
        StringBuilder sb = new StringBuilder("SELECT log_id, order_no, action_type, action_time, emp_id, details FROM sales_log WHERE 1=1 ");
        List<Object> params = new ArrayList<>();
        if (orderNo != null && !orderNo.isEmpty()) { sb.append(" AND order_no = ? "); params.add(orderNo); }
        if (empId != null) { sb.append(" AND emp_id = ? "); params.add(empId); }
        sb.append(" ORDER BY action_time DESC LIMIT 100");
        try (Connection c = Data04Utile.getConnection();
             PreparedStatement ps = c.prepareStatement(sb.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            try (ResultSet rs = ps.executeQuery()) {
                List<LogEntity> list = new ArrayList<>();
                while (rs.next()) {
                    LogEntity l = new LogEntity();
                    l.setLogId(rs.getInt("log_id"));
                    l.setOrderNo(rs.getString("order_no"));
                    l.setActionType(rs.getString("action_type"));
                    l.setActionTime(rs.getTimestamp("action_time"));
                    l.setEmpId(rs.getInt("emp_id"));
                    l.setDetails(rs.getString("details"));
                    list.add(l);
                }
                return list;
            }
        }
    }
}
