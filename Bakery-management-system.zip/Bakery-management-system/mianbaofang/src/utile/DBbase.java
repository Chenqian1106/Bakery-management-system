package utile;

public class DBbase {
}
