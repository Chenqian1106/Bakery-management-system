import utile.Data04Utile;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestTrigger {


    public static void main(String[] args) {
        try {
//            String inserSql = " INSERT INTO users (name) VALUES ('John')";
//            up(inserSql);
//            String delSql = " delete from users where id = 5 ";
//            up(delSql);


            String updateSql = "  Update sales set sales_amount='10000' where sales_id='5'";
            up(updateSql);
            query();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     *  query data from database
     * @throws Exception
     */
    public static void query() throws Exception {

        Connection con = utile.Data04Utile.getConnection();
        //3 query to execute
        String query = "SELECT * FROM audit_log";
        //4 statem  Database operation object
        Statement stmt = con.createStatement();
        //5  funciton to execute query and get result set
        ResultSet rs = stmt.executeQuery(query);

        // 6 if  next row  is exsit  then  execute  loop
        while (rs.next()) {
            //process each row of result set
            int id = rs.getInt("log_id");
            double previous_amount = rs.getDouble("previous_amount");
            double new_amount = rs.getDouble("new_amount");
            System.out.println("id="+id+" previous_amount="+previous_amount
            +" new_amount="+new_amount);
        }
        //7close resources
        rs.close();
        stmt.close();
        con.close();
    }


    /**
     *
     * @param sql  insert, delete, update sql
     * @throws Exception
     */
    public  static  void  up(String sql) throws Exception {

        Connection con = utile.Data04Utile.getConnection();
        //4 statem  Database operation object
        Statement stmt = con.createStatement();
        //5  funciton to execute query and get result set
        int rows = stmt.executeUpdate(sql);
        // int > 0  insert  successfully
        if (rows > 0) {
            System.out.println(" successfully");
        }else{
            System.out.println(" failed");
        }
        //7close resources
        stmt.close();
        con.close();
    }
}