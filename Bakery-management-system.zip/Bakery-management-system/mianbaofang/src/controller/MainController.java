package controller;

import entity.EmpEntity;
import entity.FoodEntity;
import entity.LogEntity;
import service.EmpService;
import service.FoodService;
import service.LogService;
import service.SalesService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class MainController {
    private EmpService empService = new EmpService();
    private FoodService foodService = new FoodService();
    private SalesService salesService = new SalesService();
    private LogService logService = new LogService();
    private EmpEntity currentUser;

    public void start() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("=== 面包房管理系统 ===");
            while (true) {
                if (currentUser == null) {
                    System.out.print("账号: ");
                    String account = sc.nextLine().trim();
                    System.out.print("密码: ");
                    String pwd = sc.nextLine().trim();
                    currentUser = empService.login(account, pwd);
                    if (currentUser == null) {
                        System.out.println("登录失败，重试。");
                        continue;
                    } else {
                        System.out.println("登录成功，欢迎 " + currentUser.getEmpName() + "（" + currentUser.getEmpRole() + "）");
                    }
                }

                if (isManagerRole(currentUser.getEmpRole())) {
                    managerMenu(sc);
                } else {
                    clerkMenu(sc);
                }
            }
        } catch (Exception e) {
            System.out.println("系统异常：" + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean isManagerRole(String role) {
        if (role == null) return false;
        role = role.trim();
        return "MANAGER".equalsIgnoreCase(role) || "店长".equals(role);
    }

    private String normalizeRoleInput(String input) {
        if (input == null) return "STAFF";
        input = input.trim();
        if (input.equalsIgnoreCase("MANAGER") || input.equals("店长")) return "MANAGER";
        return "STAFF";
    }

    private void managerMenu(Scanner sc) throws Exception {
        while (true) {
            System.out.println("\n1. 员工管理  2. 商品管理  3. 销售登记  4. 查看日志  5. 导出报表  6. 注销  0. 退出");
            System.out.print("选择: ");
            String ch = sc.nextLine().trim();
            switch (ch) {
                case "1":
                    employeeManage(sc);
                    break;
                case "2":
                    foodManage(sc);
                    break;
                case "3":
                    createOrderFlow(sc);
                    break;
                case "4":
                    viewLogsFlow(sc);
                    break;
                case "5":
                    System.out.print("导出路径（绝对路径，例如 D:\\\\mianbaofang_report.txt）: ");
                    String path = sc.nextLine().trim();
                    if (path.isEmpty()) path = "D:/mianbaofang_report.txt";
                    salesService.exportReport(path);
                    System.out.println("报表已导出至 " + path);
                    break;
                case "6":
                    currentUser = null;
                    return;
                case "0":
                    System.out.println("系统退出。");
                    System.exit(0);
                default:
                    System.out.println("无效输入。");
            }
        }
    }

    private void clerkMenu(Scanner sc) throws Exception {
        while (true) {
            System.out.println("\n1. 浏览商品  2. 销售登记  3. 查看日志  4. 注销  0. 退出");
            System.out.print("选择: ");
            String ch = sc.nextLine().trim();
            switch (ch) {
                case "1":
                    listProducts();
                    break;
                case "2":
                    createOrderFlow(sc);
                    break;
                case "3":
                    viewLogsFlow(sc);
                    break;
                case "4":
                    currentUser = null;
                    return;
                case "0":
                    System.out.println("退出系统。");
                    System.exit(0);
                    break;
                default:
                    System.out.println("无效选择。");
            }
        }
    }

    private void employeeManage(Scanner sc) throws Exception {
        System.out.println("\n员工管理：1. 查看员工 2. 新增员工 3. 修改员工 4. 删除员工 0. 返回");
        System.out.print("选择: ");
        String ch = sc.nextLine().trim();
        switch (ch) {
            case "1":
                List<EmpEntity> emps = empService.listEmployees();
                if (emps.isEmpty()) System.out.println("无员工记录");
                else emps.forEach(e -> System.out.println(e.toString()));
                break;
            case "2":
                System.out.print("姓名: ");
                String n = sc.nextLine().trim();
                System.out.print("角色(店长/店员 或 MANAGER/STAFF): ");
                String r = sc.nextLine().trim();
                System.out.print("账号: ");
                String a = sc.nextLine().trim();
                System.out.print("密码: ");
                String p = sc.nextLine().trim();
                String roleNorm = normalizeRoleInput(r);
                empService.addEmployee(n, roleNorm, a, p);
                System.out.println("新增成功");
                break;
            case "3":
                System.out.print("员工ID: ");
                int id = Integer.parseInt(sc.nextLine().trim());
                System.out.print("姓名: ");
                String nn = sc.nextLine().trim();
                System.out.print("角色(店长/店员 或 MANAGER/STAFF): ");
                String rr = sc.nextLine().trim();
                System.out.print("密码: ");
                String pp = sc.nextLine().trim();
                String roleN = normalizeRoleInput(rr);
                empService.updateEmployee(id, nn, roleN, pp);
                System.out.println("修改成功");
                break;
            case "4":
                System.out.print("员工ID: ");
                int did = Integer.parseInt(sc.nextLine().trim());
                empService.deleteEmployee(did);
                System.out.println("删除成功");
                break;
            case "0":
                return;
            default:
                System.out.println("无效选择");
        }
    }

    private void foodManage(Scanner sc) throws Exception {
        System.out.println("\n商品管理：1. 查看商品 2. 新增商品 3. 修改商品 4. 下架/上架 0. 返回");
        System.out.print("选择: ");
        String ch = sc.nextLine().trim();
        switch (ch) {
            case "1":
                listProducts();
                break;
            case "2":
                System.out.print("名称: ");
                String name = sc.nextLine().trim();
                System.out.print("分类: ");
                String cat = sc.nextLine().trim();
                System.out.print("单价: ");
                double price = Double.parseDouble(sc.nextLine().trim());
                System.out.print("单位: ");
                String unit = sc.nextLine().trim();
                System.out.print("描述: ");
                String desc = sc.nextLine().trim();
                foodService.addFood(name, cat, price, unit, desc);
                System.out.println("新增商品成功");
                break;
            case "3":
                System.out.print("商品ID: ");
                int pid = Integer.parseInt(sc.nextLine().trim());
                System.out.print("新名称: ");
                String nn = sc.nextLine().trim();
                System.out.print("新价格: ");
                double np = Double.parseDouble(sc.nextLine().trim());
                System.out.print("新描述: ");
                String nd = sc.nextLine().trim();
                foodService.updateFood(pid, nn, np, nd);
                System.out.println("修改成功");
                break;
            case "4":
                System.out.print("商品ID: ");
                int sid = Integer.parseInt(sc.nextLine().trim());
                System.out.print("下架请输 INACTIVE，上架请输 ACTIVE: ");
                String st = sc.nextLine().trim().toUpperCase();
                if (!"ACTIVE".equals(st) && !"INACTIVE".equals(st)) st = "INACTIVE";
                if ("ACTIVE".equals(st)) {
                    foodService.updateFood(sid, getProductName(sid), getProductPrice(sid), getProductDesc(sid));
                    System.out.println("已上架（实际修改仅状态），请在数据库中设置 status='ACTIVE' 若需要");
                } else {
                    foodService.deactivateFood(sid);
                    System.out.println("已下架");
                }
                break;
            case "0":
                return;
            default:
                System.out.println("无效选择");
        }
    }

    private String getProductName(int id) {
        try {
            List<FoodEntity> list = foodService.listActiveFoods();
            for (FoodEntity f : list) if (f.getProductId() == id) return f.getProductName();
        } catch (Exception ignored) {}
        return "";
    }

    private double getProductPrice(int id) {
        try {
            return foodService.getPriceById(id);
        } catch (Exception ignored) {}
        return 0.0;
    }

    private String getProductDesc(int id) {
        try {
            List<FoodEntity> list = foodService.listActiveFoods();
            for (FoodEntity f : list) if (f.getProductId() == id) return f.getDescription();
        } catch (Exception ignored) {}
        return "";
    }

    private void listProducts() {
        try {
            List<FoodEntity> list = foodService.listActiveFoods();
            System.out.println("ID | 名称 | 价格 | 单位 | 库存");
            for (FoodEntity f : list) {
                int inv = foodService.getInventory(f.getProductId());
                System.out.printf("%d | %s | ￥%.2f | %s | %d%n", f.getProductId(), f.getProductName(), f.getPrice(), f.getUnit(), inv);
            }
        } catch (Exception e) {
            System.out.println("读取商品失败：" + e.getMessage());
        }
    }

    private void createOrderFlow(Scanner sc) {
        try {
            listProducts();
            Map<Integer, Integer> order = new LinkedHashMap<>();
            while (true) {
                System.out.print("输入商品ID（回车结束）: ");
                String s = sc.nextLine().trim();
                if (s.isEmpty()) break;
                int id = Integer.parseInt(s);
                System.out.print("数量: ");
                int qty = Integer.parseInt(sc.nextLine().trim());
                order.put(id, order.getOrDefault(id, 0) + qty);
            }
            if (order.isEmpty()) {
                System.out.println("订单为空，取消");
                return;
            }
            System.out.print("支付方式 (CASH/WECHAT/ALIPAY): ");
            String pay = sc.nextLine().trim().toUpperCase();
            if (pay.isEmpty()) pay = "CASH";
            System.out.print("备注: ");
            String remark = sc.nextLine().trim();
            salesService.createSale(currentUser.getEmpId(), order, pay, remark);
            System.out.println("订单创建成功");
        } catch (Exception e) {
            System.out.println("创建订单失败: " + e.getMessage());
        }
    }

    private void viewLogsFlow(Scanner sc) {
        try {
            System.out.print("按订单号查询（回车跳过）: ");
            String orderNo = sc.nextLine().trim();
            System.out.print("按员工ID查询（回车跳过）: ");
            String empIdS = sc.nextLine().trim();
            Integer empId = null;
            if (!empIdS.isEmpty()) empId = Integer.parseInt(empIdS);
            List<LogEntity> logs = logService.queryLogs(orderNo.isEmpty() ? null : orderNo, empId);
            if (logs.isEmpty()) {
                System.out.println("没有日志记录");
                return;
            }
            System.out.println("logId | orderNo | action | time | empId | details");
            for (LogEntity l : logs) {
                System.out.println(l.toString());
            }
        } catch (Exception e) {
            System.out.println("查询日志失败: " + e.getMessage());
        }
    }
}
