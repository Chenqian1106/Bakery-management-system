package entity;

import java.sql.Timestamp;

public class LogEntity {
    private int logId;
    private String orderNo;
    private String actionType;
    private Timestamp actionTime;
    private int empId;
    private String details;

    public int getLogId() { return logId; }
    public void setLogId(int logId) { this.logId = logId; }

    public String getOrderNo() { return orderNo; }
    public void setOrderNo(String orderNo) { this.orderNo = orderNo; }

    public String getActionType() { return actionType; }
    public void setActionType(String actionType) { this.actionType = actionType; }

    public Timestamp getActionTime() { return actionTime; }
    public void setActionTime(Timestamp actionTime) { this.actionTime = actionTime; }

    public int getEmpId() { return empId; }
    public void setEmpId(int empId) { this.empId = empId; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }

    @Override
    public String toString() {
        return String.format("[%d] %s | %s | 员工ID:%d | %s | %s",
                logId, orderNo, actionType, empId,
                actionTime != null ? actionTime.toString() : "", details);
    }
}
