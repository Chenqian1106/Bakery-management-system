package entity;

public class EmpEntity {
    private int empId;
    private String empName;
    private String empRole;
    private String empAccount;
    private String empPassword;
    private String hireDate;

    public int getEmpId() { return empId; }
    public void setEmpId(int empId) { this.empId = empId; }

    public String getEmpName() { return empName; }
    public void setEmpName(String empName) { this.empName = empName; }

    public String getEmpRole() { return empRole; }
    public void setEmpRole(String empRole) { this.empRole = empRole; }

    public String getEmpAccount() { return empAccount; }
    public void setEmpAccount(String empAccount) { this.empAccount = empAccount; }

    public String getEmpPassword() { return empPassword; }
    public void setEmpPassword(String empPassword) { this.empPassword = empPassword; }

    public String getHireDate() { return hireDate; }
    public void setHireDate(String hireDate) { this.hireDate = hireDate; }

    @Override
    public String toString() {
        return String.format("ID:%d | 姓名:%s | 角色:%s | 账号:%s | 入职时间:%s",
                empId, empName, empRole, empAccount, hireDate);
    }
}
